/**
 * Created by Administrator on 2017/8/24.
 */
import Vue from 'vue';
export default new Vue();
