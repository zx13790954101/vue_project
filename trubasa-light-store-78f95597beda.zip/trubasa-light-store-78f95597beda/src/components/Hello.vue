<template>
  <div class="hello">

  </div>
</template>

<script>
  import bus from '../assets/bus'
export default {
  name: 'hello',
  data () {
    return {

    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
