###components
- CustomerManage 客户管理
- EditAddress 
- GoodImg 商品列表缩略图，有默认图片占位，图片加载完成后替换默认图片，区域为正方形
- GoodImgLimit 邻居装修列表页缩略图，下部拥有遮罩层备注
- GoodSelect 邻居装修列表页缩略图，下部拥有遮罩层备注
- GoodTab 
- ImgControl 配灯场景图片组件，可以修改图片曝光、角度、大小等熟悉
- ImgDetail 图片大图，查看图片大图时使用
- ImgLimit 列表图片缩略图，自动适应不同尺寸图片，区域为正方形
- ImgUpload 图片上传控件
- ImgWindow 商品详情图片控件
- LeftSide
- MyHeader
- MySwiper
- SwitchItem
- TypeSelect

###pages
